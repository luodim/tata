function fit() {
  let scale = 1
  function setRem() {
    const { clientWidth, clientHeight } = document.documentElement
    const node = document.querySelector('#h5-container')
    if (clientWidth >= clientHeight) {
      // 横屏
      node && (node.style.transform = `rotate(-90deg)`)
      scale = Math.max(clientWidth / 1500, clientHeight / 750)
      // doOffset(node, false)
    } else {
      // 竖屏
      scale = Math.max(clientHeight / 1500, clientWidth / 750)
      node && (node.style.transform = `rotate(0deg)`)
      // doOffset(node, true)
    }
    document.documentElement.style.fontSize = scale + 'px'
  }
  window.onresize = setRem
  setRem()
}

function needRouter() {
  if (!(
    /(iPhone|iPad|iPod|iOS|Android|Windows Phone|BlackBerry|SymbianOS)/i.test(
      navigator.userAgent
    )
  )) {
    console.log('is pc')
    window.open('https://ht.wanmei.com/', '_self')
  }
}

fit()
needRouter()
